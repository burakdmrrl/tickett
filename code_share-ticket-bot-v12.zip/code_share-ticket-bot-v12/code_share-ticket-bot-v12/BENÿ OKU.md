<h1>Code Share V12 Ticket Botu Altyapısı</h1>

<a href="https://discord.gg/Sf9XES6">
  Sunucuya Gelmek için Tıkla! </a>
  
  <h1></h1>

<h1>Bu Konuda Türkiyenin En İyisi!</h1>
  <h1></h1>
  <a href="https://codeshare.xyz/uptime">Botunu 7/24 Aktif Tutmak İçin Tıkla!</a>
  
  ****
_..:: BILGILER::.._

**Eğerki Projeniz Glitch de Var Olacak İse**

**ayarlar.js Kısmındaki TOKEN Kısmına Bot Tokeninizi Yazmayın!**

**Projenizdeki .env İsmindeki Dosyaya Şu Şekilde Tokeninizi Yazın!**

**TOKEN=KENDİ BOT TOKENİN**

**DataBase orio.db Modülüdür!**


**NOT 1: ayarlar.js Dosyasını Kendinize Göre Doldurmadan Projeye Başlamayın!**

**NOT 2: Eğer Projeniz Genel Herkese Açık veya Public Bot Olacaksa Projenizi Gizlemeyi Unutmayın!**

**NOT 3: Logda Bir Sorun Yaşarsanız Çözemez iseniz Destek Almak için Sunucumuza Gele Bilirsiniz!**

**NOT 4: Asla ve Asla Kim Olursa Olsun Projenizi Kimse ile Paylaşmayınız!**

**NOT 5: Komutlar Klasörüne Dosya Eklemek için komutlar/komut-ismi.js Şeklinde Yükleme Yapınız! Örnek: komutlar/reboot.js**
****
## Bu Altyapı Discord.js V12 Sürümüne Göre Türkçe Dil Uyumlu Kodlanmıştır!

_Code Share Ekibi İyi Günler Diler!_

_Umut Bayraktar_
